// more expansion
;!function (window, $, undefined) {


	var setMoreExpansion = (function(){
															
	function setMoreExpansion(bindDom, options) {
		this.$this = bindDom;
		this.setOptions(options);
		this.setMenu();
	};
	
	setMoreExpansion.prototype.defaultOpts = {
		except: '.link-group-more',
		menu: '.menu-links-list'
	};
	
	setMoreExpansion.prototype.setOptions = function(options) {
		this.opts = $.extend({}, this.defaultOpts, options);
	};
	
	setMoreExpansion.prototype.setMenu = function(){
		var opts = this.opts;
		
		jQuery(this.$this).each(function(index){
			
			var $wrap = jQuery(this),
				$links = $wrap.children('li:not(' + opts.except + ')'),
				$more = $wrap.find(opts.except),
				$moreLinks = $more.find(opts.menu).children('li'),
				_wrapWidth = $wrap.width(),
				_moreWidth = $more.width(),
				_sumWidth = 0,
				_linksLength = $links.length,
				_moreLinksLength = $moreLinks.length,
				_n = 0,
				bool_more = $more.css('display') == 'inline-block' ? true : false,
				bool_set = true;
			
			// load, resize, and reduce
			$links.each(function(i){
				_n++;
				
				var $li = jQuery(this);
				_sumWidth += $li.outerWidth(true);
				
				
				if (bool_more && (_n == 1)) _sumWidth = _sumWidth + _moreWidth;
				
				if (_sumWidth >= _wrapWidth) {
					bool_set = false;
					
					if (!bool_more) _wrapWidth = _wrapWidth - _moreWidth;
					
					_sumWidth = _sumWidth - $li.outerWidth(true);
					
					if (_sumWidth >= _wrapWidth && _moreLinksLength == 0) {
						$links.eq(i-1).appendTo($more.css('display', 'inline-block').find(opts.menu));
					}
					
					for (i; i<=_linksLength; i++){
						if (!bool_more && (i == _linksLength - 1)) {
							if (_moreLinksLength > 0) {
								$links.eq(i).prependTo($more.find(opts.menu));
							}else {
								$links.eq(i).appendTo($more.css('display', 'inline-block').find(opts.menu));
							}
						}
						if (_moreLinksLength > 0) {
							$links.eq(i).prependTo($more.find(opts.menu));
						}else{
							$links.eq(i).appendTo($more.css('display', 'inline-block').find(opts.menu));
						}
					}
				}	
			});
			
			// plus
			if (bool_set && bool_more) {
				if (_moreLinksLength > 2) {
					if (_sumWidth + realWidth($moreLinks.eq(0)) <= _wrapWidth) {
						$moreLinks.eq(0).insertBefore($more);
					}
				}else {
					if (_sumWidth - _moreWidth + realWidth($moreLinks.eq(0)) + realWidth($moreLinks.eq(1)) <= _wrapWidth) {
						$moreLinks.eq(0).insertBefore($more);
						$moreLinks.eq(1).insertBefore($more);
						$more.css('display', 'none');
					}
				}
			}
			
			
		});
	};
	
	setMoreExpansion.prototype.resizeWindow = (function(){
		
		var setMoreExpansionTimer = null;
		$(window).on('resize', function(e){
			if (setMoreExpansionTimer) {
				clearTimeout(setMoreExpansionTimer);
			}
			setMoreExpansionTimer = setTimeout(function(){
				jQuery('ul.link-group').setMoreExpansion();
			}, 100);
		});
	})();
	
	return setMoreExpansion;
	
	})();
	
	function realWidth(obj) {
	var clone = obj.clone();
	clone.css({
	    visibility: "hidden",
	    display: "inline-block"
	});
	$('body').append(clone);
	var width = clone.outerWidth(true) + 30; //margin-right=30px
	clone.remove();
	return width;
	}
	
	$.fn.setMoreExpansion = function(opts) {
	var $this = $(this),
		data = $this.data();
		
	if (data.setMoreExpansion) {
		delete data.setMoreExpansion;
	}
	if (opts !== false) {
		data.setMoreExpansion = new setMoreExpansion($this, opts);
	}
	
	return data.setMoreExpansion;
	};

}(window, jQuery);
jQuery('ul.link-group').setMoreExpansion();