jQuery(window).load(function(){
	/* banner, hero module */
	var bannerSwiper = new Swiper('#heroModule',{
		calculateHeight: true,
		loop: true,
		autoPlay: 5000
	});
	jQuery('#heroModule .swiper-button-prev').click(function(){
		bannerSwiper.swipePrev();
	});
	jQuery('#heroModule .swiper-button-next').click(function(){
		bannerSwiper.swipeNext();
	});
	jQuery('#heroModule').mouseenter(function(){
		bannerSwiper.stopAutoplay();
	}).mouseleave(function(){
		bannerSwiper.startAutoplay();
	});
});