/* *******************************
 * Popout.js v1.0.0
 * Creator: Carl Liu
 * Date: 2016.4.1
 * Notice: The Plugin structure and style base on centerPopup from old.
 * ******************************* */

// <a href="javascript:;" class="open-popup btn" data-source-id="Popup_Content">normal</a>
// <div id="Popup_Content" class="centerPopup-source">
//     <!-- your content begin -->
//     <div class="centerPopup-normal-content">
//         <p class="content">......</p>
//     </div>
//     <!-- your content end -->
// </div>

;
! function(window, $, document, undefined) {
    /*Event:(
     *shown.ng.popout,
     *hidden.ng.popout,
     *loaded.ng.popout)*/


    var Popout = function(element, options) {
        this.init("popout", element, options);
    }

    // Default options define
    Popout.VERSION = "1.1.0";
    Popout.SELECTORS = {
        toggleSelector: ".open-popup",
        popupSelector: ".centerPopup",
        bodySelector: ".centerPopup-body",
        sourceSelector: ".centerPopup-source",
        closeSelector: ".centerPopup-close",
        maskSelector: "#overlay"
    };
    Popout.TRANSITION_DURATION = 300;
    Popout.BACKDROP_TRANSITION_DURATION = 150;
    Popout.DEFAULTS = {
        trigger: "click", //trigger: click
        placement: "center", //placement:center/follow
        ismask: true, //ismask: true/false
        isarrow: false, //isArrow: true/false
        type: "popout",
        template: "<div class='centerPopup'><div class='centerPopup-body'><a href='javascript:;' class='fa fa-close centerPopup-close'></a>$$content$$</div></div>"
    };
    // Alias
    Popout.fn = Popout.prototype;

    //Initialization
    Popout.fn.init = function(type, element, options) {
        var ths = this;

        this.options = $.extend({}, Popout.SELECTORS, Popout.DEFAULTS, options);
        this.type = type || this.options.type;
        this.$element = $(element);
        this.$source = $("#" + this.$element.data("source-id"));
        this.$mask = $(Popout.SELECTORS.maskSelector);

        this.trigger(type, this.options.toggleSelector);
        this.$element.trigger("loaded.ng.popout");
    };
    //Destroy
    Popout.fn.destroy = function() {

    };
    //Trigger bind
    Popout.fn.trigger = function(type, selector) {
        var triggers = this.options.trigger.split('');

        for (var i = triggers.length; i--;) {
            var trigger = triggers[i];

            if (trigger == "click") {
                this.$element.on("click." + type, selector, $.proxy(this.toggle, this));
            }
        }
    }

    // Event
    Popout.fn.toggle = function() {
        this.$element.hasClass("is-open") ? this.hide() : this.show();
    };

    // Get source
    Popout.fn.getSource = function() {
        return this.$source = $("#" + this.options.sourceId);
    };

    // Get template
    Popout.fn.addTemplate = function(targetId, json) {
        this.$template = $(this.getTemplate(json)).attr("id", targetId);

        $("body").append(this.$template);
    };

    // Get template
    Popout.fn.getTemplate = function(json) {
        //e.g. json={content:"This is content."}
        return this.setTemplate(json)
    };

    // Set template
    Popout.fn.setTemplate = function(json) {
        var source = this.options.template,
            result = "";

        for (var key in json) {
            var check = this.checkKey(key, source);
            if (check.has) {
                result = source.replace(check.regx, json[key]);
            }
        }
        return result;
    };

    Popout.fn.checkKey = function(key, source) {
            var regx = new RegExp("\\$\\$" + key + "\\$\\$", "ig");

            return {
                regx: regx,
                has: regx.test(source)
            }
        }
        // Get Content

    Popout.fn.getContent = function() {
        return this.$source.html();
    };

    // Context
    Popout.fn.getContext = function($obj) {
        $obj = $($obj);

        var ofst = $obj.offset() || {},
            offset = {
                width: $obj.width() || 0,
                height: $obj.outerHeight() || 0
            };

        return $.extend({}, offset, ofst);
    }

    // Set position
    Popout.fn.setPosition = function() {
        var $element = this.$element,
            $target = $("#" + $element.data("target-id")),
            targetCxt = this.getContext($target),
            placement = this.options.placement,
            bodyCxt = this.getContext($("body")),
            winCxt = this.getContext($(window)),
            elementCxt = this.getContext($element),
            position = {},
            top, left;

        switch (placement) {
            case "center":

                top = (winCxt.height - targetCxt.height) / 2;
                left = (bodyCxt.width - targetCxt.width) / 2 || 0;
                break;
            case "follow":
                var followSwitch = followSwitch(winCxt, targetCxt, elementCxt);

                top = followSwitch.top;
                left = followSwitch.left;
                break;
            default:

                break;
        }

        position = {
            top: top,
            left: left
        };

        function followSwitch(allCxt, targetCxt, sourceCxt) {
            var currLeft = sourceCxt.left + targetCxt.width;

            return {
                top: sourceCxt.top + sourceCxt.height,
                left: currLeft > allCxt.width ? (allCxt.width - targetCxt.width) : sourceCxt.left
            }

        }

        $target.css(position);
    };

    // Close Popout
    Popout.fn.hide = function() {
        $("#" + (this.$element.removeClass("is-open").data("target-id"))).hide();
        this.$element.trigger("hidden.ng.popout");

        //If use mask layer
        if (this.options.ismask) {
            $(this.options.maskSelector).hide();
        }
    };

    Popout.fn.getTarget = function(targetId) {
        return $("#" + targetId);
    }

    // show
    Popout.fn.show = function() {
        var ths = this,
            target_id = this.$element.addClass("is-open").data("target-id");

        // Generation popout layer and id
        if (!target_id) {
            var createTargetId = this.getUID(this.options.type);

            this.$element.attr("data-target-id", createTargetId);

            this.addTemplate(createTargetId, {
                content: this.getContent()
            });
        }

        this.$target = this.getTarget(target_id).show();
        this.setPosition();

        this.$element.trigger("shown.ng.popout");

        //If use mask layer
        $(this.options.ismask && this.options.maskSelector)
            .show()
            .one('click', function() {
                $(ths.options.maskSelector).hide();
                ths.hide();
            });
    };

    // General Popout Id
    Popout.fn.getUID = function(prefix) {
        do prefix += ~~(Math.random() * 1000000)
        while (document.getElementById(prefix))
        return prefix
    }

    // Plugin Definition
    function Plugin(option) {
        return this.each(function() {
            var $this = $(this),
                data = $this.data("ng.popout");

            options = option == "object" ? $.extend({}, option, $this.data()) : $this.data();

            if (!data && /destroy|hide/.test(option)) return;
            if (!data) $this.data('ng.popout', (data = new Popout(this, options)));
            if (typeof option == 'string') data[option]();
        })
    }

    var old = $.fn.popout;

    $.fn.popout = Plugin;
    $.fn.popout.Constructor = Popout;

    // POPOVER NO CONFLICT
    // ===================
    $.fn.popout.noConflict = function() {
        $.fn.popout = old
        return this
    }

    // POPOUT DATA-API
    var Handler = {
        toggle: function() {
            Plugin.call($(this), "toggle");
        },
        close: function() {
            var id = $(this).closest(Popout.SELECTORS.popupSelector).attr("id"),
            $toggle =$("[data-target-id="+id+"]");
            Plugin.call($toggle, "hide");
        }
    }

    $(document).on("click.ng.popout", Popout.SELECTORS.toggleSelector, Handler.toggle);

    $(document).on("click.ng.popout", Popout.SELECTORS.closeSelector, Handler.close);

}(window, jQuery, document);
