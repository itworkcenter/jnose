/* *******************************
 * Popout.js v1.0.0
 * Creator: Carl Liu
 * Date: 2016.4.1
 * ******************************* */

;
! function(window, $, undefined) {

    var Popout = function(element, options) {
        this.init(element, options);
    }

    // Default options define
    Popout.VERSION = "1.0.0";
    Popout.DEFAULTS = {
        template: "<div class='popout-inner'><div class='popout-head'><span class='popout-head-icon'></span><h3 class='popout-head-title'>Popout</h3></div><div class='popout-content'></div><div class='popout-button'><button class='btn btn-primary'>X</button></div></div>"
    };
    Popout.fn = Popout.prototype;

    //Initialization
    Popout.fn.init = function(element, options) {
        var ths = this;

        this.opts = $.extend({}, this.DEFAULTS, options);
        this.$el = $(element);

        // Driven Process
        this.$el.on("click", function() {
            ths.click($(this));
        });
    };
    Popout.fn.click = function($curr) {
        var ths = this,
            targetId = $curr.data("target"),
            $target = $("#" + targetId)
        $overlay = $("#overlay");

        // Toggle
        if ($target.size()) {
            if ($target.hasClass("is-open")) {
                ths.close($target,function(){
                    $target.removeClass("is-open");
                    $overlay.hide();
                });
            } else {
                $target.addClass("is-open");
                ths.position($target);

				ths.open($target,function(){
                    $overlay.show();
                });

            }
        }

        //close
        $('#overlay, .popout-button-close')
            .show()
            .one('click', function() {
                $('#overlay').hide();
                $target.removeClass("is-open");
            });
    };

    // Context
    Popout.fn.getContext = function($obj) {
        $obj = $($obj);

        var ofst = $obj.offset() || {},
            offset = {};


        $obj.width() && (offset.width = $obj.width());
        $obj.height() && (offset.height = $obj.height());

        offset = $.extend({}, offset, ofst);

        return offset;
    }

    // Position
    Popout.fn.position = function($target) {
        var ths = this,
            offset = {},
            el_ctxt = ths.getContext(this.$el),
            target_ctxt = ths.getContext($target),
            win_ctxt = ths.getContext(window),
            all_left = target_ctxt.width + el_ctxt.left;

            console.log(win_ctxt.width)
            console.log(all_left)
            console.log(target_ctxt.width)
            console.log(el_ctxt.left)

        if (all_left > win_ctxt.width) {
            offset.left = win_ctxt.width-target_ctxt.width-10;
        } else {
            offset.left = el_ctxt.left;
        }

        offset.top = el_ctxt.top;

        $target.css(offset)
    };



    // Close Popout
    Popout.fn.close = function() {
        $target.animate({
            width: 0,
            height:0
        }, 500,function(){
            $target.width("auto").height("auto");
            back&&back();
        });
    };
    // Open Popout
    Popout.fn.open = function($target,back) {
        var target_ctxt = this.getContext($target);
        $target.width(0).height(0);
        $target.animate({
            width: "350",
            height:target_ctxt.height
        }, 500,function(){
            back&&back();
        });
    };


    // Plugin Definition
    function Plugin(option) {
        return this.each(function() {
            var $this = $(this),
                data = $this.data("ng.popout"),
                option = typeof option == 'object' && option;

            var option = typeof option == 'object' && option;

            if (!data && /destroy|hide/.test(option)) return;
            if (!data) $this.data('ng.popout', (data = new Popout(this, option)));
            if (typeof option == 'string') data[option]();
        })
    }

    var old = $.fn.popout;

    $.fn.popout = Plugin;
    $.fn.popout.Constructor = Popout;

    // POPOVER NO CONFLICT
    // ===================
    $.fn.popout.noConflict = function() {
        $.fn.popout = old
        return this
    }



}(window, jQuery);
